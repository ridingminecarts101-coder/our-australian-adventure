# Our Australian Adventure PWA

A mobile-first PWA prototype for Riley & Elli. It contains 500 Australian adventure missions, local progress, ratings and memories.

## Run it

Serve this folder from any static HTTPS host (GitHub Pages, Cloudflare Pages, Netlify, etc.). Open the URL on both phones and use **Add to Home Screen**.

## Shared Riley/Elli sync

The prototype stores progress in each browser with localStorage. For true shared progress between phones, connect the app to a small hosted database (recommended: Supabase) and replace the local save functions in `app.js` with authenticated shared records. No secret keys are included in this prototype.

## Sources

The dataset was curated from real Australian tourism/attraction information and destination knowledge, with official tourism references including Tourism Australia, South Australian Tourism Commission, Visit Victoria and VisitCanberra. Availability, access, seasonal closures, Traditional Owner permissions and operator status should be checked before visiting.
